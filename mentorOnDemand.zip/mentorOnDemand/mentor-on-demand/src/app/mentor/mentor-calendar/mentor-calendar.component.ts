import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-calendar',
  templateUrl: './mentor-calendar.component.html',
  styleUrls: ['./mentor-calendar.component.css']
})
export class MentorCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
